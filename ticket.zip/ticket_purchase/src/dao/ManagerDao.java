package dao;

public interface ManagerDao {
	public boolean login(String name,String password);
}
